package net.minecraft.src;

public class BlockDirt extends Block {
	protected BlockDirt(int blockID, int tex) {
		super(blockID, tex, Material.grass);
	}
}
